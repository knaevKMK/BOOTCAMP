﻿namespace Jobs.Domain.ViewModels
{
public  class SkillViewModel
    {
        public string name { get; set; }
    }
}
