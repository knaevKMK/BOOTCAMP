﻿namespace Jobs.Domain.ViewModels
{
public    class JobViewModel
    {
        public string Title { get; set; }
        public decimal Salary { get; set; }
        public string Description { get; set; }
    }
}
