﻿
namespace Jobs.Domain.ViewModels
{
public  class InterviewViewModel
    {
        public string Candidate { get; set; }
        public string Job { get; set; }
        public string Recruiter { get; set; }
    }
}
